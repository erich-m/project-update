//Scanner Demo
//Lets write a program...

//create program body

//create a scanner

//Functions:
//gets a username
//gets 2 integers from the user
//gets an operation from the user (add, subtract multiply, divide)
//performs operation
//prints result

package ErrorCheckDemo;

/*Access Levels
public
	can be accessed by anything in any folder
private
	it cannot be accessed by anything in the folder or another folder
protected
	can be accessed by anything in the package folder
	any child classes that are in other folders
blank
	package level protection: anything in the package can access it
*/


import java.util.Scanner;

public class ErrorCheckDemo{//class name must match the program name
	public static void main(String [] args){//main code block
		System.out.println("Working");

		Scanner input = new Scanner(System.in);//create scanner
		/*formot for the user input:
		next____() where the blank is the data type*/



		System.out.println("Whats your name:");
		//nextLine will read in an entire line from the console
		//next reads in a single word from the console
		String name = input.nextLine();

		/*try-catch-finally*/

	  /*in the try block:
	  code is attempted to be run
	  sometimes there are errors the programmer does not expect (typical with input) that requires special action
	  if there is an error in the try block, the program shifts to the appropriate catch block
	  Examples: InputMismatchException, NumberFormatException, Exception*/

	  /*in the catch block(s)
	  there is a "header" which defines the type of exception to catch
	  variable name is usually e or err
	  code in the catch block is executed ONLY IF the exception thrown in the try matches the one expected by the catch
	  there CAN be mutliple catch blocks for multiple errors*/

	  /*in the finally block
	  any additional, common code, is executed*/


	  //declare and initialize the input variables, a b and operation
	    double a = 0;
		double b = 1;

		int operation = 0;

		boolean error = true;//create a while loop variable
		while(error){//while there is an error (aka error==true)
			error = true;
			try{//create the try block
				System.out.println("First Number:");
				String aString = input.next();//get a string input. getting a string allows the user to input whater they want, but can also possibly be converted into a number
				a = Double.parseDouble(aString);
				System.out.println("Second Number:");
				String bString = input.next();
				b = Double.parseDouble(bString);//converts a string to a double

				System.out.println("Add(0), Subtract(1), Multiply(2), Divide(3)");
				String operationString = input.next();
				operation = Integer.parseInt(operationString);//converts a string into an integer

				//Hint 1: check for division and b=0
				//Hint 2: how are exceptions created (Should be similar to this:   t***w n*w Ex******n();  )

				error = false;
			}catch(NumberFormatException e){//catch converion error
				System.out.println("Oh noes");
			}
				//Hint 3: What exception type is for a general exception?
			catch(Exception e){//just for example, catch general exception
				System.out.println("Oh noes 2");  //Hint 3: add a new catch block here for a general error. Just use the other two as a guide
			}finally{//run the common code
				System.out.println("Done");
			}
		}

		double result = 0;

		if(operation == 0){
			result = a + b;
		}else if(operation == 1){
			result = a - b;
		}else if(operation == 2){
			result = a * b;
		}else{
			result = a / b;
		}

		System.out.println("Result : " + result);
	}
}