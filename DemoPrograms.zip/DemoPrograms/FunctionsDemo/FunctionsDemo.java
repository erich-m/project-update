//Functions (Methods)!!!

//functions are a way of grouping similar code
//extremely useful

//this program makes use of functions in a very simple way

//the term "function" and "method" are interchangable
//they allow us to define a block of code

package FunctionsDemo;//package name

public class FunctionsDemo{//main class
	public static void main(String [] args){//main method: you have sectretly been working in a method the entire time
		//Void Functions:
		//do not return anything
		//are used to make repetition easier

		printLines();//call the function "printLines" 4 times
		printLines();
		printLines();
		printLines();

		//Parameter Functions:
		//have parameters (inputs)
		//more useful than void functions
		//can modify input

		int num1 = 1;//define and initialize 4 integers
		int num2 = 2;
		int num3 = 4;
		int num4 = 8;

		printAdd(num1,num2,num3,num4);//call "printAdd" 4 times
		printAdd(num3,num3,num2,num1);
		printAdd(num1,num2,num3,num4);
		printAdd(num3,num3,num2,num1);

		printName("Erich");//call "printName" with only 1 string
		printName("Erich", 1);//call "printName" with only 1 string and an integer

		//Functions:
		//can have inputs
		//have a return line
		//you must return the same variable type as the function declaration
		//most common and useful

		int a = 1;//define and initialize 4 integers
		int b = 2;
		int c = 4;
		int d = 8;

		System.out.println(returnAdd(a,b,c,d));//print the result from calling "returnAdd"
		System.out.println(returnAdd(a,b,c,a));
		System.out.println(returnAdd(a,b,a,d));
		System.out.println(returnAdd(d,b,d,d));
	}

	//public static String welcome (String name){
	//return "Welcome " + name;
	//}

	//public defines the access level
	//static is an advanced topic
	//String is the function type
	//welcome is the name of the function
	//String name is the parameter type and parameter name
	//return statement allows the function call to be used as a string
	

}

	public static void printLines(){//void method does not have parameters or a return statement
		System.out.println("I am printing this out many times");
		System.out.println("Here is some more stuff");
		System.out.println("Here is even more stuff");
		System.out.println("Even more");
		System.out.println("more");
		System.out.println("lol");
	}

	public static void printAdd(int a,int b,int c,int d){//parameter methods have parameters but no return value
		System.out.println(a * b + c - d);
	}

	//method overloading
	//You can have the same name of funtion if...
	//the parameters are different types
	//different number of parameter
	public static void printName(String name){//parameter methods have parameters but no return value
		System.out.println("Hello " + name);
	}

	public static void printName(String name, int a){//parameter methods have parameters but no return value
		System.out.println("Hello " + name + ". Here is a number " + a);
	}

	public static int returnAdd(int a,int b,int c,int d){//function methods can have parameters (they do not have to), but they have a return statement
		return (a * b + c - d);//this allows the function call to act as an integer (eg. int myInt = returnAdd(a,b,c,d))
	}
}