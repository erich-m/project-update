//Scanner Demo
//Lets write a program...

//create program body

//create a scanner

//Functions:
//gets a username
//gets 2 integers from the user
//gets an operation from the user (add, subtract multiply, divide)
//performs operation
//prints result

package ScannerDemo;

/*Access Levels
public
	can be accessed by anything in any folder
private
	it cannot be accessed by anything in the folder or another folder
protected
	can be accessed by anything in the package folder
	any child classes that are in other folders
blank
	package level protection: anything in the package can access it
*/


import java.util.Scanner;

public class ScannerDemo{//class name must match the program name
	public static void main(String [] args){//main code block
		System.out.println("Working");

		Scanner input = new Scanner(System.in);//create scanner
		/*formot for the user input:
		next____() where the blank is the data type*/


		System.out.println("Whats your name:");
		//nextLine will read in an entire line from the console
		//next reads in a single word from the console
		String name = input.nextLine();

		System.out.println("First Number:");
		double a = input.nextDouble();//get a double from the user
		System.out.println("Second Number:");
		double b = input.nextDouble();//get a second double from the user

		System.out.println("Add(0), Subtract(1), Multiply(2), Divide(3)");
		int operation = input.nextInt();

		double result = 0;

		if(operation == 0){
			result = a + b;
		}else if(operation == 1){
			result = a - b;
		}else if(operation == 2){
			result = a * b;
		}else{
			result = a / b;
		}

		System.out.println("Result : " + result);
	}
}