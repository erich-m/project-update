
//Loops and Arrays

//Review
//System.out.println("");
/*Data types
boolean
byte
char
short
int
float
long
double*/
/*Scanner
User input
Read in different data types*/
/*If/else statements*/
/*Error checking
try/catch/finally statements
Catch different Exceptions: Number format exceptions, Exception*/
/*Methods (Functions)
void: no parameters or return
parameter: no return
function: both return and parameter*/

package LoopsAndArraysDemo;

public class LoopsAndArraysDemo{
	public static void main (String[] args){
		/*
		while
			runs while a condition is true

		for
			runs for a specific number of iterations

			iteration is just a single run of the loop
		*/

		//while
		int counter = 0;

		while(counter < 100){

			//Modulous Operator: %
			//System.out.println(counter % 5);
			counter++;
			//++,add 1 to current value
			//--, subtracts 1

			//+=,-=,*=,/= followed by the other number eg counter+=1;
		}
		//while

		//for loops
		for(int i = -5;i <= 5;i++){
			for(int k = 0;k < 10;k++){
				//System.out.println(i + k);
			}
		}
		//for loops

		
		          //index: 0 1 2 3 4
		int [] my_array = {2,4,6,8,10};
		int [] my_array2 = new int[5];

		for(int n = 0;n <= my_array.length-1;n++){
			System.out.println("my array: " + my_array[n]);
			my_array2[n] = my_array[n] * 2;

			System.out.println("my array 2: " + my_array2[n]);
		}

		//Arrays:
			//Watch for setting values correctly
			//Index out of bounds exceptions

		//System.out.println(args[0]);

		//one dimensional array
		int[] random1 = {2,6,2,3,4,5};

		for(int i = 0;i < random1.length;i++){
			System.out.println(random1[i]);
			if(i ==3){
				break;
			}
		}

		//two dimensional array
		int[][] random2 = {  {1,2,3}  ,  {4,5,6}  ,  {7,8,9}  };//the inner arrays are all the same lenght
		//int[][] random2 = new int[3][3];

		for(int k = 0; k < random2.length;k++){
			//loop prints out elements from the middle arrays
			for(int l = 0;l < random2[k].length;l++){
				System.out.print(random2[k][l] + " ");
			}
			System.out.println();
		}

		//int[][][][][][][][][][] random3 = new int
	}
}