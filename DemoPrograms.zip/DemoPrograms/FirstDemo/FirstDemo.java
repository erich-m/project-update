//First Demo Program
package FirstDemo;//package name

public class FirstDemo{//class name
	public static void main(String [] args){//main method
		System.out.println("Hello World\n");//print hello world to the screen

		/*What is a bit?
		*a bit is a 1 or a 0
		*is represented by on or off in a computer
		*base 2 numbers
			
		What is a byte?
		*a byte is a string of 8 individual bits
		*a byte can represent 2^n base 10 numbers, where n is the number of bytes
		*/


		//DATA TYPES:
		//data types are just strings of bytes of different lengths

		//What is a boolean:
		// a true or false variable
		//most used for conditionals
		//Number of Bytes: 1
		boolean var1 = true;
		System.out.println("boolean: " + var1);
		var1 = false;
		System.out.println("Var1: " + var1);

		System.out.println("\n");

		//What is a byte:
		//a byte is a string of 8 individual bits
		//Number of Bytes: 1
		byte var2 = 127;
		System.out.println("byte: " + var2);
		var2 = -128;
		System.out.println("Var2: " + var2);

		System.out.println("\n");

		//What is a char:
		//a char is a symbol associated with a decimal value
		//that descimal value is represented by the bytes
		//Number of Bytes: 2
		//ASCII Table
		//some languages, a char is only 1 byte
		//comes from the encoding type
		char var3 = 'a';
		System.out.println("char: " + var3);
		var3 = 'A';
		System.out.println("Var3: " + var3);

		System.out.println("\n");

		//What is a short:
		//a small integer
		//better efficieny for storage
		//Number of Bytes: 2
		short var4 = Short.MIN_VALUE;
		System.out.println("short: " + var4);
		var4 = Short.MAX_VALUE;
		System.out.println("Var4: " + var4);

		System.out.println("\n");

		//What is an integer:
		//most commonly used number data type
		//used to represent general numbers
		//Number of bytes: 4
		int var5 = Integer.MAX_VALUE;
		System.out.println("int: " + var5);
		var5 = Integer.MIN_VALUE;
		System.out.println("Var5: " + var5);

		System.out.println("\n");

		//What is a float:
		//a float is an approximation of a decimal
		//similar to scientific mode on a calculator
		//efficient in storing fractional values
		//Number of bytes: 4
		float var6 = Float.MIN_VALUE;
		System.out.println("float: " + var6);
		var6 = Float.MAX_VALUE;
		System.out.println("Var6: " + var6);

		System.out.println("\n");

		//What is a long:
		//a long is a really really long number format
		//less efficient on space
		//Number of bytes: 8
		long var7 = Long.MIN_VALUE;
		System.out.println("long: " + var7);
		var7 = Long.MAX_VALUE;
		System.out.println("Var7: " + var7);

		System.out.println("\n");

		//What is a double:
		//Most common decimal format
		//less effient spacewise than floats
		//Number of bytes: 8
		double var8 = Double.MAX_VALUE;
		System.out.println("double:" + var8);
		var8 = Double.MIN_VALUE;
		System.out.println("Var8: " + var8);

		System.out.println("\n");

	}//close main method
}//close main class