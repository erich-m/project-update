package Challenge1;
//////////////////////////////////Problem Workspace///////////////////////////////////////////////////////////////////////////////////////////  
            
            
            
//////////////////////////////////Problem Workspace///////////////////////////////////////////////////////////////////////////////////////////  
public class primeDemoCompleted
{
      public static void main(String [] args){
            
            boolean test = true;
            
            //Setup//Off Limits: Usable Vairalbes are T and N[] (length T)
            int T;
            int[] N = {8,4,7,21};
            
            if(test){
                  T = 4;
            }else{
                  T = (int)rand(1,1000);
                  N = new int[T];
                  for(int t = 1;t <= T;t++){
                        N[t-1] = (int)rand(4,1000000);
                        System.out.println(N[t-1]);
                  }
            }
            //Setup//Off Limits: Usable Vairalbes are T and N[] (length T)
//////////////////////////////////Problem Workspace///////////////////////////////////////////////////////////////////////////////////////////  
            
            for(int i =0;i < T;i++){
                        int currentN = N[i]*2;
                        for(int j = 1;j < currentN;j++){
                              int a = currentN - j;
                              int b = currentN - a;
                              if(checkPrime(a) && checkPrime(b) && a != 1 && b != 1){
                                    System.out.println(N[i] + "->" + a + " " + b);
                                    break;
                              }
                        }
            }
            
//////////////////////////////////Problem Workspace///////////////////////////////////////////////////////////////////////////////////////////  
      }
//////////////////////////////////Problem Workspace///////////////////////////////////////////////////////////////////////////////////////////  
            
      public static boolean checkPrime(int p){
            int multiple = 0;
            for(int i = 1;i <= p;i++){//for each integer value between 1 and p, check the modulus of that number with the loop value
                  if(p % i == 0){
                        multiple++;
                  }
            }
            
            if(multiple > 2){
                  return false;
            }else{
                  return true;
            }
      }
            
//////////////////////////////////Problem Workspace///////////////////////////////////////////////////////////////////////////////////////////  
      //Random Double Function//Off Limits
      public static double rand(int min,int max){
            return Math.random() * (max-min+1)+min;
      }
      //Random Double Function//Off Limits
}